//pinegrow.config.cjs

module.exports = {
  liveDesigner: {
    repoRoot: '../../',
    //...
  }
}