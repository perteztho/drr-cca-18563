import React, { useState, useEffect } from 'react';
import { Search, Menu, X } from 'lucide-react';

interface HeaderProps {
  onEmergencyClick: () => void;
  onIncidentClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onEmergencyClick, onIncidentClick }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { 
      name: 'Services', 
      href: '#services',
      submenu: [
        'Emergency Response',
        'Risk Assessments',
        'Damage Assessment',
        'Contingency Plan',
        'Training Program',
        'Rehabilitation Program',
        'Crowd Control',
        'Technical Assistance'
      ]
    },
    {
      name: 'Hazards',
      href: '#hazards',
      submenu: [
        'Coastal Erosion',
        'Earthquake',
        'Human-Caused',
        'Thunder & Lightning',
        'Drought',
        'Flood',
        'Landslide',
        'Tsunami',
        'Volcanic Ash',
        'Wind/Typhoon'
      ]
    },
    {
      name: 'Information',
      href: '#information',
      submenu: [
        'News & Updates',
        'Events Calendar',
        'Weather Updates',
        'Announcements',
        'FAQs'
      ]
    },
    {
      name: 'Resources',
      href: '#resources',
      submenu: [
        'Municipal Map',
        'Evacuation Centers',
        'Emergency Kit',
        'Downloads',
        'Useful Links'
      ]
    },
    { name: 'Contact', href: '#contact' }
  ];

  return (
    <>
      <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-blue-950/95 backdrop-blur-md shadow-lg' : 'bg-blue-950'
      } border-b-4 border-yellow-500`}>
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          {/* Logo and Title */}
          <div className="flex items-center space-x-4">
            <img 
              src="https://res.cloudinary.com/dedcmctqk/image/upload/v1750079276/logome_h9snnx.webp" 
              alt="MDRRMO" 
              className="h-12 w-auto"
            />
            <div>
              <h1 className="font-bold text-yellow-500 text-lg md:text-xl">MDRRMO</h1>
              <p className="text-yellow-500 text-xs md:text-sm">PIO DURAN, ALBAY</p>
            </div>
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            {/* Barangay Portal Button */}
            <button className="bg-yellow-500 text-blue-950 px-4 py-2 rounded-md font-bold hover:bg-yellow-400 transition-colors duration-300">
              <span className="hidden md:inline">Barangay Portal</span>
              <span className="md:hidden">Portal</span>
            </button>

            {/* Search Toggle */}
            <button 
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="text-yellow-500 text-xl hover:text-yellow-400 transition-colors"
            >
              <Search size={20} />
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-yellow-500 md:hidden"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Search Container */}
        {isSearchOpen && (
          <div className="bg-blue-900 py-3 px-4 shadow-lg border-t border-blue-800">
            <div className="container mx-auto">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search..."
                  className="w-full pl-4 pr-12 py-2 rounded-lg bg-blue-800 text-yellow-500 placeholder-yellow-300 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                />
                <Search className="absolute right-4 top-2.5 text-yellow-500" size={16} />
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-blue-950/95 backdrop-blur-md pt-20">
          <div className="container mx-auto px-4">
            <nav className="flex flex-col space-y-4">
              {navItems.map((item, index) => (
                <div key={index}>
                  <a
                    href={item.href}
                    className="text-yellow-500 text-xl py-2 border-b border-blue-800 hover:text-yellow-400 transition-colors"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.name}
                  </a>
                  {item.submenu && (
                    <div className="ml-4 mt-2 space-y-1">
                      {item.submenu.map((subItem, subIndex) => (
                        <a
                          key={subIndex}
                          href="#"
                          className="block text-yellow-300 text-sm py-1 hover:text-yellow-500 transition-colors"
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          {subItem}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              
              <div className="pt-4">
                <input
                  type="text"
                  placeholder="Search..."
                  className="w-full pl-4 pr-12 py-2 rounded-lg bg-blue-900 text-yellow-500 placeholder-yellow-300 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                />
              </div>
            </nav>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;