import React, { createContext, useContext, useState, useEffect } from 'react';

interface NewsItem {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  date: string;
  author: string;
  status: 'published' | 'draft';
}

interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  tags: string[];
  status: 'active' | 'inactive';
}

interface IncidentReport {
  id: string;
  reporterName: string;
  contactNumber: string;
  location: string;
  incidentType: string;
  description: string;
  urgency: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'pending' | 'in-progress' | 'resolved';
  dateReported: string;
  referenceNumber: string;
}

interface DataContextType {
  // News
  news: NewsItem[];
  addNews: (news: Omit<NewsItem, 'id'>) => void;
  updateNews: (id: string, news: Partial<NewsItem>) => void;
  deleteNews: (id: string) => void;
  
  // Services
  services: Service[];
  addService: (service: Omit<Service, 'id'>) => void;
  updateService: (id: string, service: Partial<Service>) => void;
  deleteService: (id: string) => void;
  
  // Incident Reports
  incidents: IncidentReport[];
  addIncident: (incident: Omit<IncidentReport, 'id' | 'dateReported' | 'referenceNumber'>) => void;
  updateIncident: (id: string, incident: Partial<IncidentReport>) => void;
  deleteIncident: (id: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [news, setNews] = useState<NewsItem[]>([
    {
      id: '1',
      title: 'BDRRM Planning Training/Workshop for Barangay Officials',
      excerpt: 'On June 25, 2024, the Municipal Disaster Risk Reduction and Management Office (MDRRMO) conducted an essential training session...',
      content: 'Full content of the news article would go here...',
      image: 'https://res.cloudinary.com/dedcmctqk/image/upload/v1750575265/487673077_1062718335885316_7552782387266701410_n_gexfn2.jpg',
      date: '2024-06-29',
      author: 'MDRRMO Staff',
      status: 'published'
    },
    {
      id: '2',
      title: 'Successful Nationwide Simultaneous Earthquake Drill Conducted',
      excerpt: 'The municipality participated in the 2nd quarter nationwide simultaneous earthquake drill with over 5,000 participants...',
      content: 'Full content of the news article would go here...',
      image: 'https://res.cloudinary.com/dedcmctqk/image/upload/v1750575261/489043126_1065374988952984_1331524645056736117_n_fbmvch.jpg',
      date: '2023-06-09',
      author: 'MDRRMO Staff',
      status: 'published'
    }
  ]);

  const [services, setServices] = useState<Service[]>([
    {
      id: '1',
      title: 'Disaster Prevention & Mitigation',
      description: 'Immediate response to disaster-related emergencies with our trained response teams.',
      icon: 'Shield',
      tags: ['Search & Rescue', 'Medical Assistance', 'Fire Response'],
      status: 'active'
    },
    {
      id: '2',
      title: 'Disaster Preparedness',
      description: 'Regular training programs for community members, volunteers, and responders.',
      icon: 'Heart',
      tags: ['First Aid Training', 'DRRM Workshops', 'Drills'],
      status: 'active'
    }
  ]);

  const [incidents, setIncidents] = useState<IncidentReport[]>([]);

  // News functions
  const addNews = (newsItem: Omit<NewsItem, 'id'>) => {
    const newNews = {
      ...newsItem,
      id: Date.now().toString()
    };
    setNews(prev => [newNews, ...prev]);
  };

  const updateNews = (id: string, updates: Partial<NewsItem>) => {
    setNews(prev => prev.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const deleteNews = (id: string) => {
    setNews(prev => prev.filter(item => item.id !== id));
  };

  // Services functions
  const addService = (service: Omit<Service, 'id'>) => {
    const newService = {
      ...service,
      id: Date.now().toString()
    };
    setServices(prev => [newService, ...prev]);
  };

  const updateService = (id: string, updates: Partial<Service>) => {
    setServices(prev => prev.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const deleteService = (id: string) => {
    setServices(prev => prev.filter(item => item.id !== id));
  };

  // Incidents functions
  const addIncident = (incident: Omit<IncidentReport, 'id' | 'dateReported' | 'referenceNumber'>) => {
    const newIncident = {
      ...incident,
      id: Date.now().toString(),
      dateReported: new Date().toISOString(),
      referenceNumber: `RD-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0')}`,
      status: 'pending' as const
    };
    setIncidents(prev => [newIncident, ...prev]);
  };

  const updateIncident = (id: string, updates: Partial<IncidentReport>) => {
    setIncidents(prev => prev.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  };

  const deleteIncident = (id: string) => {
    setIncidents(prev => prev.filter(item => item.id !== id));
  };

  return (
    <DataContext.Provider value={{
      news, addNews, updateNews, deleteNews,
      services, addService, updateService, deleteService,
      incidents, addIncident, updateIncident, deleteIncident
    }}>
      {children}
    </DataContext.Provider>
  );
};