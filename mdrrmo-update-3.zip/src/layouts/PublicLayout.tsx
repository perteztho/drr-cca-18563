import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import BackToTop from '../components/BackToTop';

const PublicLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        onEmergencyClick={() => {}}
        onIncidentClick={() => {}}
      />
      <main>
        <Outlet />
      </main>
      <Footer />
      <BackToTop />
    </div>
  );
};

export default PublicLayout;