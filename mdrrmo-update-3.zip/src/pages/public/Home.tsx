import React, { useState } from 'react';
import Hero from '../../components/Hero';
import About from '../../components/About';
import Services from '../../components/Services';
import Planning from '../../components/Planning';
import EmergencyProcedures from '../../components/EmergencyProcedures';
import News from '../../components/News';
import FAQ from '../../components/FAQ';
import Resources from '../../components/Resources';
import ImageGallery from '../../components/ImageGallery';
import IncidentModal from '../../components/modals/IncidentModal';
import HotlineModal from '../../components/modals/HotlineModal';
import SuccessModal from '../../components/modals/SuccessModal';
import { useData } from '../../contexts/DataContext';

const Home: React.FC = () => {
  const [isIncidentModalOpen, setIsIncidentModalOpen] = useState(false);
  const [isHotlineModalOpen, setIsHotlineModalOpen] = useState(false);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [referenceNumber, setReferenceNumber] = useState('');
  
  const { addIncident } = useData();

  const handleIncidentSubmit = (formData: any) => {
    // Add incident to data context
    addIncident(formData);
    
    // Generate reference number
    const refNum = `RD-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0')}`;
    setReferenceNumber(refNum);
    
    // Close incident modal and show success modal
    setIsIncidentModalOpen(false);
    setIsSuccessModalOpen(true);
  };

  return (
    <>
      <Hero 
        onEmergencyClick={() => setIsHotlineModalOpen(true)}
        onIncidentClick={() => setIsIncidentModalOpen(true)}
      />
      <About />
      <Services />
      <Planning />
      <EmergencyProcedures />
      <News />
      <FAQ />
      <Resources />
      <ImageGallery />

      <IncidentModal
        isOpen={isIncidentModalOpen}
        onClose={() => setIsIncidentModalOpen(false)}
        onSubmit={handleIncidentSubmit}
      />

      <HotlineModal
        isOpen={isHotlineModalOpen}
        onClose={() => setIsHotlineModalOpen(false)}
      />

      <SuccessModal
        isOpen={isSuccessModalOpen}
        onClose={() => setIsSuccessModalOpen(false)}
        referenceNumber={referenceNumber}
      />
    </>
  );
};

export default Home;